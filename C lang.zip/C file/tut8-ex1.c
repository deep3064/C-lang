#include<stdio.h>

int main()
{
    /* code */
    int a,b,c,d,e,f,g,h,i,j,k;
    a=5;
    b=1;
    c=2;
    d=3;
    e=4;
    f=5;
    g=6;
    h=7;
    i=8;
    j=9;
    k=10;

    printf("5 * 1 = %d\n", a*b);
    printf("5 * 2 = %d\n", a*c);
    printf("5 * 3 = %d\n", a*d);
    printf("5 * 4 = %d\n", a*e);
    printf("5 * 5 = %d\n", a*f);
    printf("5 * 6 = %d\n", a*g);
    printf("5 * 7 = %d\n", a*h);
    printf("5 * 8 = %d\n", a*i);
    printf("5 * 9 = %d\n", a*j);
    printf("5 * 10 = %d\n", a*k);
    
    return 0;
}
